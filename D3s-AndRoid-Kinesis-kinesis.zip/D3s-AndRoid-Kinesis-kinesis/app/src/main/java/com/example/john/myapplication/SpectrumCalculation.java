package com.example.john.myapplication;

import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

/**
 * Created by Zheng on 2/24/2016.
 */
public class SpectrumCalculation {

    public static short getGrossCount(byte[] byteArray) {
        int byteArrayLength = byteArray.length;
        if (byteArrayLength == 8205) {
            short pointer = 11;
            short grossCount = 0;
            while (pointer < 8202) {
                byte[] byteArraySingleBin = {byteArray[pointer], byteArray[pointer + 1]};
                short binCount = getShortFromLittleEndianRange(byteArraySingleBin);
                grossCount = (short) (grossCount + binCount);
                pointer = (short) (pointer + 2);
            }
            return grossCount;
        } else {
            return (short) 99999;
        }
    };

    public static long getTimeInterval(byte[] byteArray) {

        if (byteArray.length == 8205) {

            long value = byteArray[5] & 0xFF;
            value |= (byteArray[6] << 8) & 0xFFFF;
            value |= (byteArray[7] << 16) & 0xFFFFFF;
            value |= (byteArray[8] << 24) & 0xFFFFFFFF;
            return value;
        } else {
            return (long) 100;
        }
    }

    public static short getShortFromLittleEndianRange(byte[] byteArray){
        return (short)((byteArray[1] << 8) + (byteArray[0] & 0xff));
    }



}
