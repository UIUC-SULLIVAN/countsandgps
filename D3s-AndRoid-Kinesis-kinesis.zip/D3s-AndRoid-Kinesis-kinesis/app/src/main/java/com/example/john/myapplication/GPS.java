package com.example.john.myapplication;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

/**
 * Created by Michael Cheng on 5/20/2016.
 */
public class GPS implements LocationListener {

    public static double latitude; //latitude variable
    public static double longitude; //longitude variable

    @Override
    public void onLocationChanged(Location location) {

        location.getLatitude();
        location.getLongitude();
        latitude=location.getLatitude(); //Assign latitude value
        longitude=location.getLongitude(); //Assign longitude value
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

        //Nothing here
    }

    @Override
    public void onProviderEnabled(String provider) {

        //Print "GPS is ENABLED";
    }

    @Override
    public void onProviderDisabled(String provider) {

        //Print "GPS is DISABLED";
    }
}
