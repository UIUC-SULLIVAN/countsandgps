package com.example.john.myapplication;

/*
Author: Zheng Liu
Acknowledgement:
    Mhjeong for his help in bluetooth connection code

 */

import android.bluetooth.*;
import android.os.Handler;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by john on 2/19/2016.
 */
public class ConnectedThread extends Thread {
    private final BluetoothSocket mmSocket;
    private final InputStream mmInStream;
    private final OutputStream mmOutStream;
    private static final String TAG = "--GetSpectrum Length";

    public ConnectedThread(BluetoothSocket socket) {

        mmSocket = socket;
        Log.v("","Pass connectThread to connectedThread");
        InputStream tmpIn = null;
        OutputStream tmpOut = null;

        // Get the input and output streams, using temp objects because
        // member streams are final
        try {
            tmpIn = socket.getInputStream();
            tmpOut = socket.getOutputStream();
        } catch (IOException e) { Log.v(TAG, "error 4");}

        mmInStream = tmpIn;
        mmOutStream = tmpOut;
        Log.v("","Prepared in&out stream");
   }

    /* Call this from the main activity to send data to the remote device and read the output */
    public byte[] getSpectrum(byte[] bytes) {

        //buffer to save spectrum
        byte[] buffer = new byte[8205];

        //send command to detector
        try {
            mmOutStream.write(bytes);
        } catch (IOException e) {Log.v(TAG, "error 6"); }

        //wait one second to let bluetooth transform data
        try {
            Thread.sleep(1000);                 //1000 milliseconds is one second.
        } catch(InterruptedException ex) {
            Thread.currentThread().interrupt();
        }

        //read data from detector
        try {
              // buffer store for the stream
            int length; // bytes returned from read()
            length = mmInStream.read(buffer);
            //Log.v(TAG, String.valueOf(length));
            //Log.v(TAG, new String(buffer, "UTF-8"));


        } catch (IOException e) {Log.v(TAG, "error 5"); }

        return buffer;
    }

    /* Call this from the main activity to shutdown the connection */
    public void cancel() {
        try {
            mmSocket.close();
        } catch (IOException e) { }
    }
}
