package com.example.john.myapplication;

import android.content.Context;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.kinesis.kinesisrecorder.KinesisFirehoseRecorder;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;

import java.io.File;
/*
Author: Zheng Liu
Acknowledgement:
    Mhjeong for his help in bluetooth connection code

 */
public class Util {

    // We only need one instance of the clients and credentials provider
    private static CognitoCachingCredentialsProvider sCredProvider;
    private static KinesisFirehoseRecorder firehoseRecorder;



    /**
     * Gets an instance of CognitoCachingCredentialsProvider which is
     * constructed using the given Context.
     *
     * @param context An Context instance.
     * @return A default credential provider.
     */
    private static CognitoCachingCredentialsProvider getCredProvider(Context context) {
        if (sCredProvider == null) {
            sCredProvider = new CognitoCachingCredentialsProvider(
                    context.getApplicationContext(),
                    Constants.COGNITO_POOL_ID,
                    Regions.US_EAST_1);
        }
        //Log.v("-------",sCredProvider.getCachedIdentityId());
        return sCredProvider;
    }

    /**
     * Gets an instance of a S3 client which is constructed using the given
     * Context.
     *
     * @param context An Context instance.
     * @return A default S3 client.
     */
    public static KinesisFirehoseRecorder firehoseRecorder(Context context) {
        if (firehoseRecorder == null) {
            firehoseRecorder = new KinesisFirehoseRecorder(
                    context.getCacheDir(),
                    Regions.US_EAST_1,
                    getCredProvider(context.getApplicationContext())
                    );
        }
        return firehoseRecorder;
    }


}


