package com.example.john.myapplication;

/*
Author: Zheng Liu
Acknowledgement:
    Mhjeong for his help in bluetooth connection code

 */

import android.bluetooth.*;
import android.util.Log;

import java.io.IOException;
import java.util.UUID;

/**
 * Created by john on 2/19/2016.
 */
public class ConnectThread extends Thread {
    public final BluetoothSocket mmSocket;
    public final BluetoothDevice mmDevice;
    public BluetoothAdapter mBluetoothAdapter;
    private static final String TAG = "ttttttttttt";
    private static final UUID MY_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public ConnectThread() {
        // Use a temporary object that is later assigned to mmSocket,
        // because mmSocket is final
        BluetoothSocket tmp = null;

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            Log.v(TAG, "error 1");
        }
        mmDevice = mBluetoothAdapter.getRemoteDevice("55:33:39:87:6F:01");
        Log.v("--1. connected to",mmDevice.getName());
        // Get a BluetoothSocket to connect with the given BluetoothDevice
        try {
            // MY_UUID is the app's UUID string, also used by the server code
            tmp = mmDevice.createRfcommSocketToServiceRecord(MY_UUID);
            Log.v("--2. opened","RFCOMM service");
        } catch (IOException e) { Log.v(TAG, "error 2");}
        mmSocket = tmp;
    }

    public void run() {
        // Cancel discovery because it will slow down the connection
        //mBluetoothAdapter.cancelDiscovery();

        try {
            // Connect the device through the socket. This will block
            // until it succeeds or throws an exception
            Log.v("--2.1.0",mmSocket.getRemoteDevice().getName());
            Log.v("--2.2.0", mmSocket.getRemoteDevice().getAddress());
            mmSocket.connect();
            Log.v("--2.1.1",mmSocket.getRemoteDevice().getName());
            Log.v("--2.2.1", mmSocket.getRemoteDevice().getAddress());
            Log.v("--3. connected to", "Socket");
        } catch (IOException connectException) {
            // Unable to connect; close the socket and get out
            Log.v(TAG, "error 3");
            Log.v("--2.1.error",mmSocket.getRemoteDevice().getName());
            Log.v("--2.2.error",mmSocket.getRemoteDevice().getAddress());
            try {
                mmSocket.close();
            } catch (IOException closeException) { }
            return;
        }
    }

    /** Will cancel an in-progress connection, and close the socket */
    public void cancel() {
        try {
            mmSocket.close();
        } catch (IOException e) { }
    }
}
