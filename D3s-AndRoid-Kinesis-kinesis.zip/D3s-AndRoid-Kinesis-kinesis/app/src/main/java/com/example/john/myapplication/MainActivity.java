package com.example.john.myapplication;

/*
Author: Zheng Liu
Acknowledgement:
    Mhjeong for his help in bluetooth connection code

 */

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.amazonaws.AmazonClientException;
import com.amazonaws.mobileconnectors.kinesis.kinesisrecorder.*;

public class MainActivity extends AppCompatActivity {

    private ConnectThread mConnectThread;
    private ConnectedThread mConnectedThread;
    private KinesisFirehoseRecorder firehoseRecorder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Create new bluetooth thread and connect it to detector
        mConnectThread = new ConnectThread();
        mConnectThread.run();
        Log.v("--M1. Create new thread", "and connect to detector");

        //Prepare the created bluetooth thread to write and read data
        mConnectedThread = new ConnectedThread(mConnectThread.mmSocket);
        Log.v("--M2. Prepare"," thread for read and write");
        //Command to get spectrum
        final byte[] command={0x07,0x00,0x00,0x07,(byte)0xc1,0x00,0x00};

        //Prepare the AWS Kinesis Firehose recorder
        firehoseRecorder = Util.firehoseRecorder(this);
        Log.v("--M3."," Firehose Recorder is ready");

         //Create button. When the button is pressed, it will read one measurement from detector.
        final Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                for (int i = 0; i < 10; i++) {

                    //time-tag of spectrum
                    Long tsLong = System.currentTimeMillis() / 1000;
                    String ts = tsLong.toString();

                    //get spectrum
                    byte[] spectrum = mConnectedThread.getSpectrum(command);
                    short grossCount = SpectrumCalculation.getGrossCount(spectrum);
                    long timeInterval = SpectrumCalculation.getTimeInterval(spectrum);
                    // get gps coordinates
                    double latitude = GPS.latitude;
                    double longitude = GPS.longitude;

                    Log.v("DetectionTime "+String.valueOf(timeInterval), "GrossCount "+String.valueOf(grossCount));


                    //Record the spectrum and gps coordinates in firehose recorder
                    if (grossCount != 0){
                        String firehoseUpload = ts + "," + timeInterval + "," + grossCount + "," + latitude + "," + longitude +"\n";
                    }
                }

                // Send previously saved data to Amazon Kinesis Firehose
                // Note: submitAllRecords() makes network calls, so wrap it in an AsyncTask.
                new AsyncTask<Void, Void, Boolean>() {
                    @Override
                    protected Boolean doInBackground(Void... v) {
                        try {
                            firehoseRecorder.submitAllRecords();
                            Log.v("----", "Submited to Kinesis Firehose");
                        } catch (AmazonClientException ace) {
                            Log.v("----", "Cannot submit records");
                        }
                        return true;
                    }
                }.execute();
            }


        });


    }
}



